document.getElementById("searchForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const keyword = document.getElementById("keyword").value.trim();
    const resultDiv = document.getElementById("results");
    resultDiv.innerHTML = "<p>⏳ Đang tìm kiếm...</p>";

    try {
        // Gửi request đến Node-RED API
        const response = await fetch(`http://localhost:1880/timkiem?q=${encodeURIComponent(keyword)}`);
        const data = await response.json();

        if (data.length === 0) {
            resultDiv.innerHTML = "<p>❌ Không tìm thấy kết quả nào.</p>";
            return;
        }

        // Hiển thị kết quả
        let html = "";
        data.forEach(book => {
            html += `
                <div class="book">
                    <h3>${book.TenSach}</h3>
                    <p><strong>Tác giả:</strong> ${book.TacGia}</p>
                    <p><strong>Thể loại:</strong> ${book.TheLoai}</p>
                    <p><strong>Năm XB:</strong> ${book.NamXB}</p>
                </div>
            `;
        });
        resultDiv.innerHTML = html;

    } catch (error) {
        console.error(error);
        resultDiv.innerHTML = "<p>⚠️ Lỗi kết nối API Node-RED!</p>";
    }
});
